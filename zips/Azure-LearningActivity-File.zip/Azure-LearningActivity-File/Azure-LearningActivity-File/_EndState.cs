﻿namespace Azure_LearningActivity_File
{
    using System;
    using Microsoft.WindowsAzure.Storage;
    using Microsoft.WindowsAzure.Storage.File;

    class EndState
    {
        static readonly string _connectionString = "";

        static void _Main(string[] args)
        {
            Console.WriteLine("Creating Directory 'dir1' and Files 'file1.txt' and 'file2.txt'...");
            CreateDirectoryAndFiles();
            Console.WriteLine();

            var file1 = GetFile();
            Console.WriteLine("Getting 'file1.txt' contents: ");
            Console.WriteLine("     " + file1.DownloadText());
            Console.WriteLine();

            Console.WriteLine("Getting 'file1.txt' metadata...");
            var metadata = file1.Metadata;
            foreach (var key in metadata.Keys)
            {
                Console.WriteLine("     " + key + " : " + metadata[key]);
            }
            Console.WriteLine();

            Console.WriteLine("Press any key to exit the learning activity application.");
            Console.ReadLine();
        }

        static void CreateDirectoryAndFiles()
        {
            CloudStorageAccount account = CloudStorageAccount.Parse(_connectionString);

            CloudFileClient client = account.CreateCloudFileClient();

            CloudFileShare share = client.GetShareReference("share1");

            CloudFileDirectory rootDir = share.GetRootDirectoryReference();
            CloudFileDirectory dir1 = rootDir.GetDirectoryReference("dir1");
            dir1.CreateIfNotExists();

            CloudFile file1 = dir1.GetFileReference("file1.txt");
            file1.UploadText("sample file 1 text");
            file1.Metadata.Add("department", "accounting");
            file1.Metadata.Add("topic", "budget");
            file1.SetMetadata();

            CloudFile file2 = dir1.GetFileReference("file2.txt");
            file2.UploadText("sample file 2 text");
        }

        static CloudFile GetFile()
        {
            CloudStorageAccount account = CloudStorageAccount.Parse(_connectionString);

            CloudFileClient client = account.CreateCloudFileClient();

            CloudFileShare share = client.GetShareReference("share1");

            CloudFileDirectory rootDir = share.GetRootDirectoryReference();
            CloudFileDirectory dir1 = rootDir.GetDirectoryReference("dir1");

            CloudFile file1 = dir1.GetFileReference("file1.txt");
            file1.FetchAttributes();
            return file1;
        }
    }
}