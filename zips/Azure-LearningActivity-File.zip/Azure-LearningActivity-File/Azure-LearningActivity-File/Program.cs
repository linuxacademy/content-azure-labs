﻿namespace Azure_LearningActivity_File
{
    using System;
    using Microsoft.WindowsAzure.Storage;
    using Microsoft.WindowsAzure.Storage.File;

    class Program
    {
        static readonly string _connectionString = "_______________";

        static void Main(string[] args)
        {
            Console.WriteLine("Creating Directory 'dir1' and Files 'file1.txt' and 'file2.txt'...");
            CreateDirectoryAndFiles();
            Console.WriteLine();

            var file1 = GetFile();
            Console.WriteLine("Getting 'file1.txt' contents: ");
            Console.WriteLine("     " + file1.DownloadText());
            Console.WriteLine();

            Console.WriteLine("Getting 'file1.txt' metadata...");
            var metadata = file1.Metadata;
            foreach (var key in metadata.Keys)
            {
                Console.WriteLine("     " + key + " : " + metadata[key]);
            }
            Console.WriteLine();

            Console.WriteLine("Press any key to exit the learning activity application.");
            Console.ReadLine();
        }

        /*
            CloudStorageAccount
            CloudStorageAccount
            CloudFileShare
            CloudFileDirectory
            CloudFile
        */
        static void CreateDirectoryAndFiles()
        {
            _______________ account = _______________.Parse(_connectionString);

            _______________ client = account.CreateCloudFileClient();

            _______________ share = client.GetShareReference("share1");

            _______________ rootDir = share.GetRootDirectoryReference();
            _______________ dir1 = rootDir.GetDirectoryReference("dir1");
            dir1.CreateIfNotExists();

            _______________ file1 = dir1.GetFileReference("file1.txt");
            file1.UploadText("sample file 1 text");
            file1.Metadata.Add("department", "accounting");
            file1.Metadata.Add("topic", "budget");
            file1.SetMetadata();

            _______________ file2 = dir1.GetFileReference("file2.txt");
            file2.UploadText("sample file 2 text");
        }

        /*
            CloudStorageAccount
            CloudStorageAccount
            CloudFileShare
            CloudFileDirectory
            CloudFile
        */
        static CloudFile GetFile()
        {
            _______________ account = _______________.Parse(_connectionString);

            _______________ client = account.CreateCloudFileClient();

            _______________ share = client.GetShareReference("share1");

            _______________ rootDir = share.GetRootDirectoryReference();
            _______________ dir1 = rootDir.GetDirectoryReference("dir1");

            _______________ file1 = dir1.GetFileReference("file1.txt");
            file1.FetchAttributes();
            return file1;
        }
    }
}