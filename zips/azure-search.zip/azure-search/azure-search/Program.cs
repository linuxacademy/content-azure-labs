﻿namespace AzureSearch
{
    using System;
    using System.Linq;
    using System.Threading;
    using Microsoft.Azure.Search;
    using Microsoft.Azure.Search.Models;
    using Microsoft.Spatial;
    using Newtonsoft.Json;

    class Program
    {
        private const string searchServiceName = "____________________";
        private const string adminApiKey = "____________________";

        private static ISearchServiceClient serviceClient = new SearchServiceClient(searchServiceName, new SearchCredentials(adminApiKey));
        private static ISearchIndexClient indexClient = serviceClient.Indexes.GetClient("hotels");


        // This sample shows how to create an index, upload documents, and query an index
        static void Main(string[] args)
        {
            //IConfigurationBuilder builder = new ConfigurationBuilder().AddJsonFile("appsettings.json");
            //IConfigurationRoot configuration = builder.Build();
            //string searchServiceName = configuration["SearchServiceName"];
            //string adminApiKey = configuration["SearchServiceAdminApiKey"];


            Console.WriteLine("{0}", "Creating index...\n");
            CreateHotelsIndex();
            Console.WriteLine();


            Console.WriteLine("{0}", "Uploading documents...\n");
            UploadDocuments();
            Console.WriteLine();


            Console.WriteLine("{0}", "Querying documents...\n");
            RunQueries();
            Console.WriteLine();


            Console.WriteLine("{0}", "Complete.  Press any key to end application...\n");
            Console.ReadKey();
        }




        /*
            IndexAction
            Index
            
            CreateOrUpdate
            Create
        */
        private static void CreateHotelsIndex()
        {
            var definition = new ____________________()
            {
                Name = "hotels",
                Fields = FieldBuilder.BuildForType<Hotel>(),
            };

            serviceClient.Indexes.____________________(definition);
        }




        /*
            Index
            Upload
            
            Index
            Upload
        */
        private static void UploadDocuments()
        {
            var hotels = new Hotel[]
            {
                new Hotel()
                { 
                    HotelId = "1", 
                    BaseRate = 199.0, 
                    Description = "Best hotel in town",
                    DescriptionFr = "Meilleur hôtel en ville",
                    HotelName = "Fancy Stay",
                    Category = "Luxury", 
                    Tags = new[] { "pool", "view", "wifi", "concierge" },
                    ParkingIncluded = false, 
                    SmokingAllowed = false,
                    LastRenovationDate = new DateTimeOffset(2010, 6, 27, 0, 0, 0, TimeSpan.Zero), 
                    Rating = 5, 
                    Location = GeographyPoint.Create(47.678581, -122.131577)
                },
                new Hotel()
                { 
                    HotelId = "2", 
                    BaseRate = 79.99,
                    Description = "Cheapest hotel in town",
                    DescriptionFr = "Hôtel le moins cher en ville",
                    HotelName = "Roach Motel",
                    Category = "Budget",
                    Tags = new[] { "motel", "budget" },
                    ParkingIncluded = true,
                    SmokingAllowed = true,
                    LastRenovationDate = new DateTimeOffset(1982, 4, 28, 0, 0, 0, TimeSpan.Zero),
                    Rating = 1,
                    Location = GeographyPoint.Create(49.678581, -122.131577)
                },
                new Hotel() 
                { 
                    HotelId = "3",
                    BaseRate = 139.0,
                    Description = "Mid-Range hotel in town",
                    DescriptionFr = "Meilleur hôtel en ville",
                    HotelName = "Average Stay",
                    Category = "Average",
                    Tags = new[] { "view", "wifi", "concierge" },
                    ParkingIncluded = true,
                    SmokingAllowed = false,
                    LastRenovationDate = new DateTimeOffset(2002, 7, 19, 0, 0, 0, TimeSpan.Zero),
                    Rating = 3,
                    Location = GeographyPoint.Create(48.479581, -122.131577)
                }
            };

            var batch = IndexBatch.____________________(hotels);

            try
            {
                indexClient.Documents.____________________(batch);
            }
            catch (IndexBatchException e)
            {
                // Sometimes when your Search service is under load, indexing will fail for some of the documents in
                // the batch. Depending on your application, you can take compensating actions like delaying and
                // retrying. For this simple demo, we just log the failed document keys and continue.
                Console.WriteLine(
                    "Failed to index some of the documents: {0}",
                    String.Join(", ", e.IndexingResults.Where(r => !r.Succeeded).Select(r => r.Key)));
            }

            Console.WriteLine("Waiting for documents to be indexed...\n");
            Thread.Sleep(2000);
        }




        /*
            Retrieve
            Search
            Query
        */
        private static void RunQueries()
        {
            SearchParameters parameters;
            DocumentSearchResult<Hotel> results;


            Console.WriteLine("Search the entire index for the term 'budget' and return only the hotelName field:\n");
            parameters =
                new SearchParameters()
                {
                    Select = new[] { "hotelName" }
                };
            results = indexClient.Documents.____________________<Hotel>("budget", parameters);
            WriteDocuments(results);


            Console.WriteLine("Apply a filter to the index to find hotels cheaper than $150 per night, ");
            Console.WriteLine("and return the hotelId and description:\n");
            parameters =
                new SearchParameters()
                {
                    Filter = "baseRate lt 150",
                    Select = new[] { "hotelId", "description" }
                };
            results = indexClient.Documents.____________________<Hotel>("*", parameters);
            WriteDocuments(results);


            Console.WriteLine("Search the entire index, order by a specific field (lastRenovationDate) ");
            Console.WriteLine("in descending order, take the top two results, and show only hotelName and ");
            Console.WriteLine("lastRenovationDate:\n");
            parameters =
                new SearchParameters()
                {
                    OrderBy = new[] { "lastRenovationDate desc" },
                    Select = new[] { "hotelName", "lastRenovationDate" },
                    Top = 2
                };
            results = indexClient.Documents.____________________<Hotel>("*", parameters);
            WriteDocuments(results);


            Console.WriteLine("Search the entire index for the term 'motel':\n");
            parameters = new SearchParameters();
            results = indexClient.Documents.____________________<Hotel>("motel", parameters);
            WriteDocuments(results);
        }

        private static void WriteDocuments(DocumentSearchResult<Hotel> searchResults)
        {
            foreach (SearchResult<Hotel> result in searchResults.Results)
            {
                Console.WriteLine(JsonConvert.SerializeObject(result.Document,Formatting.Indented));
            }

            Console.WriteLine();
            Console.WriteLine();
        }
    }
}