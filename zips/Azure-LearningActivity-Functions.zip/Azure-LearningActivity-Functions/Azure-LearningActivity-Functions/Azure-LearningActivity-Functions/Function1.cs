namespace Azure_LearningActivity_Functions
{
    using System;
    using Microsoft.Azure.WebJobs;
    using Microsoft.Azure.WebJobs.Extensions.Http;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Logging;
    using Microsoft.WindowsAzure.Storage.Table;

    public static class Function1
    {
        [FunctionName("Function1")]
        [return: Table("Table1", Connection = "StorageConnectionAppSetting")]
        public static SampleData Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] 
            HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            string name = req.Query["name"];

            return new SampleData() 
            { 
                PartitionKey = "Http", 
                RowKey = Guid.NewGuid().ToString(), 
                Text = name 
            };
        }

        /* 
            HttpTrigger
            Table 
            AuthorizationLevel
            FunctionName
            Connection
        */
        [________________("Function1")]
        [return: ________________("Table1", ________________ = "StorageConnectionAppSetting")]
        public static SampleData Run(
            [________________(________________.Anonymous, "get", "post", Route = null)] 
            HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            string name = req.Query["name"];


            return new SampleData() 
            { 
                PartitionKey = "Http", 
                RowKey = Guid.NewGuid().ToString(), 
                Text = name 
            };
        }
    }

    public class SampleData : TableEntity
    {
        public string Text { get; set; }
    }
}